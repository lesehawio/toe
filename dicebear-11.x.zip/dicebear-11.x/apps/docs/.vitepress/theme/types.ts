import type { DefaultTheme } from 'vitepress';

export type AvatarStyleMeta = {
  title?: string;
  creator?: string;
  homepage?: string;
  source?: string;
  license?: {
    name?: string;
    url?: string;
    text?: string;
  };
};

export type AvatarStyle = {
  definitionUrl?: string;
  animated?: boolean;
  /** Names of the style's animations, each one has an option of its own. */
  animations?: readonly string[];
  meta: AvatarStyleMeta;
};

export type AvatarStyles = Record<string, AvatarStyle>;

export type AvatarUniqueCount = {
  display: string;
  log10: number;
};

export type AvatarStyleSize = {
  raw: number;
  gzip: number;
};

export type AvatarStyleSizeBundle = {
  core: AvatarStyleSize;
  /** The core entry without the schema validators. */
  coreLite: AvatarStyleSize;
  converter: AvatarStyleSize;
  styles: Record<string, AvatarStyleSize>;
};

export type ThemeOptions = {
  avatarStyles: AvatarStyles;
  styleCount: number;
  animatedStyleCount: number;
  avatarUniqueCounts: Record<string, AvatarUniqueCount>;
  avatarStyleSizes: AvatarStyleSizeBundle;
  githubStars: Record<string, string>;
  /** Routes that have a Markdown mirror next to their HTML, see llms.ts. */
  llmsRoutes: readonly string[];
  /** Major version of the release train, e.g. `10`, see config/versions.ts. */
  majorVersion: string;
  /** Full text of the repo's MIT LICENSE, see config/softwareLicense.ts. */
  softwareLicense: string;
} & DefaultTheme.Config;

export type CustomStyleEntry = {
  name: string;
  definition: object;
};

export type PlaygroundStoreStyle = string;
export type PlaygroundStoreOptions = Record<string, any>;
