---
title: DiceBear as Gravatar Default Avatar
description: >
  Use DiceBear's avatar API as a privacy-focused Gravatar fallback image. Simple
  URL-based integration with no authentication required.
---

# DiceBear as Gravatar default avatar

Gravatar shows a default image for everyone without a Gravatar account, and you
can point it at the DiceBear HTTP API, so those people get a friendly generated
avatar instead of the gray silhouette.

Gravatar's
[rules for default images](https://docs.gravatar.com/sdk/images/#default-image)
change two things about the usual URL. Gravatar does not support SVG, so use the
PNG endpoint. And it ignores a query string, so pass the options in the path:
the HTTP API accepts them there if you replace the question mark with a slash
and encode the options.

::: code-group

```js [JavaScript]
const emailHash = encodeURIComponent('00000000000000000000000000000000');
const options = `seed=${emailHash}`;
const defaultImage = encodeURIComponent(
  `https://api.dicebear.com/11.x/lorelei/png?${options}` // [!code --]
  `https://api.dicebear.com/11.x/lorelei/png/${encodeURIComponent(options)}`, // [!code ++]
);

const gravatarImage = `https://www.gravatar.com/avatar/${emailHash}?d=${defaultImage}`;
// https://www.gravatar.com/avatar/00000000000000000000000000000000?d=https%3A%2F%2Fapi.dicebear.com%2F11.x%2Florelei%2Fpng%2Fseed%253D00000000000000000000000000000000
```

<!-- prettier-ignore -->
```php [PHP]
$emailHash = urlencode('00000000000000000000000000000000');
$options = sprintf('seed=%s', $emailHash);
$defaultImage = urlencode(
  'https://api.dicebear.com/11.x/lorelei/png?' . $options // [!code --]
  'https://api.dicebear.com/11.x/lorelei/png/' . urlencode($options) // [!code ++]
);

$gravatarImage = sprintf(
  'https://www.gravatar.com/avatar/%s?d=%s',
  $emailHash,
  $defaultImage
);
// https://www.gravatar.com/avatar/00000000000000000000000000000000?d=https%3A%2F%2Fapi.dicebear.com%2F11.x%2Florelei%2Fpng%2Fseed%253D00000000000000000000000000000000
```

<!-- prettier-ignore -->
```python [Python]
import urllib.parse

email_hash = urllib.parse.quote("00000000000000000000000000000000")
options = f"seed={email_hash}"
default_image = urllib.parse.quote(
    f"https://api.dicebear.com/11.x/lorelei/png?{options}",  # [!code --]
    f"https://api.dicebear.com/11.x/lorelei/png/{urllib.parse.quote(options)}",  # [!code ++]
    safe="",
)

gravatar_image = f"https://www.gravatar.com/avatar/{email_hash}?d={default_image}"
# https://www.gravatar.com/avatar/00000000000000000000000000000000?d=https%3A%2F%2Fapi.dicebear.com%2F11.x%2Florelei%2Fpng%2Fseed%253D00000000000000000000000000000000
```

<!-- prettier-ignore -->
```go [Go]
import (
	"fmt"
	"net/url"
)

emailHash := url.QueryEscape("00000000000000000000000000000000")
options := fmt.Sprintf("seed=%s", emailHash)
defaultImage := url.QueryEscape(
	fmt.Sprintf("https://api.dicebear.com/11.x/lorelei/png?%s", options), // [!code --]
	fmt.Sprintf("https://api.dicebear.com/11.x/lorelei/png/%s", url.QueryEscape(options)), // [!code ++]
)

gravatarImage := fmt.Sprintf("https://www.gravatar.com/avatar/%s?d=%s", emailHash, defaultImage)
// https://www.gravatar.com/avatar/00000000000000000000000000000000?d=https%3A%2F%2Fapi.dicebear.com%2F11.x%2Florelei%2Fpng%2Fseed%253D00000000000000000000000000000000
```

<!-- prettier-ignore -->
```dart [Dart]
final emailHash = Uri.encodeComponent('00000000000000000000000000000000');
final options = 'seed=$emailHash';
final defaultImage = Uri.encodeComponent(
  'https://api.dicebear.com/11.x/lorelei/png?$options' // [!code --]
  'https://api.dicebear.com/11.x/lorelei/png/${Uri.encodeComponent(options)}' // [!code ++]
);

final gravatarImage = 'https://www.gravatar.com/avatar/$emailHash?d=$defaultImage';
// https://www.gravatar.com/avatar/00000000000000000000000000000000?d=https%3A%2F%2Fapi.dicebear.com%2F11.x%2Florelei%2Fpng%2Fseed%253D00000000000000000000000000000000
```

<!-- prettier-ignore -->
```csharp [C#]
var emailHash = Uri.EscapeDataString("00000000000000000000000000000000");
var options = $"seed={emailHash}";
var defaultImage = Uri.EscapeDataString(
    $"https://api.dicebear.com/11.x/lorelei/png?{options}" // [!code --]
    $"https://api.dicebear.com/11.x/lorelei/png/{Uri.EscapeDataString(options)}" // [!code ++]
);

var gravatarImage = $"https://www.gravatar.com/avatar/{emailHash}?d={defaultImage}";
// https://www.gravatar.com/avatar/00000000000000000000000000000000?d=https%3A%2F%2Fapi.dicebear.com%2F11.x%2Florelei%2Fpng%2Fseed%253D00000000000000000000000000000000
```

:::
