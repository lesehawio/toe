---
title: Adventurer Neutral Presets – Avatar Style
description: >
  Ready-made option sets for the Adventurer Neutral avatar style. Copy a preset
  into your code or open it in the DiceBear playground and keep tuning from
  there.
layout: page
sidebar: false
aside: false
---

<script setup lang="ts">
import SitePresetsPage from "@theme/components/site/SitePresetsPage.vue";
</script>

<SitePresetsPage styleName="adventurer-neutral">

A preset is an ordinary set of render options. Pick one, read its code or open
it in the Playground and keep tuning. Options a preset leaves alone keep varying
with the seed, so each row lists how many distinct avatars it still gives you.

</SitePresetsPage>
